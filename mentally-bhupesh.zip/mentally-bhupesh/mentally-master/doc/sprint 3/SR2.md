Participants: Alex, Viju, Navya, Kavya, Fareeha, Malaika, Jasmine
Everyone has participated: Yes
We were able to successfully complete all our tasks in sprint 2 which is an improvement over our previous sprint where we had an outstanding task that had to be moved to the next sprint.

We decided to add a new user story for the next sprint to implement navigation through the app to different modules.

Looking back at how sprint 2 went we understood the importance of checking in often with the team and sharing progress as it helped motivate everyone in their tasks and also gave the opportunity to see how the other aspects of the project implementation are going.
In order to improve our progress for the next sprint we should work on improving how we plan our sprint. For example, we should work on the documents in advance as completing them in the last few days causes us to rush through them. This results in us not being able to think through them properly and not completing them to the best of our abilities. Secondly, for the next sprint, we should work on communicating our ideas more clearly so that everyone knows what is expected of them and what other team members want from the feature. In short, we learnt through our sprint 2 experience that better planning and clear communication are two very important factors for a successful sprint. 

Our best experience in this sprint was seeing each other’s completed modules as there were a lot of new features implemented. Our project started to become a reality as all pieces were coming together making it look like an actual app. 

There wasn't really a bad experience during sprint 2.