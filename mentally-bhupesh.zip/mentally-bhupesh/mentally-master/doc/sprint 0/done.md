The definition of done will vary depending on the task. Ideally, the term ‘done’ is when our user story has been implemented such that it is in line with our objectives and principles as stated in summary.md.

As we want to maximise user satisfaction and experience while using our app, we will be prioritizing it when programming all of the user stories. Hence, if we believe that the user story/feature will provide easy functionality for the user, it is considered to be done. Additionally, to label a user story as complete, the group must reach a consensus that there are no further tasks required to complete the story. 

