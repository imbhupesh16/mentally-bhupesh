Participants: Alex, Viju, Navya, Kavya, Fareeha, Malaika, Jasmine
Everyone has participated: yes
We were able to successfully complete all our tasks except for one. Under user story 5 our task [PAC-22] populating the profile page was implemented but had some bugs that we need to fix in sprint 2 otherwise it won't be able to load the profile page properly. 

Our new User Story would be to load the profile page 

Looking back at how sprint 1 went we discussed that we should continue to hold meetings to discuss the ups and downs of our progress and how as a team we should tackle these problems.
In order to improve our progress for the next sprint we should break down tasks in a more efficient manner and that everyone should know exactly what he/she needs to do.
Organization is a key factor in completing a user story succsessfully and we found that from our sprint 1 experience we lacked in that area.

Our best experience was the process of accepting pull requests to merge and being able to see all of our userstories come together into one app. There wasn't really a bad experience during sprint 1.
