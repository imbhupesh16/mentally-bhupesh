package com.pacman.MentAlly.ui.menu;


public class image {
    int image;
    public image(int image){
        this.image=image;

    }
    public int getImage(){
        return  image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
